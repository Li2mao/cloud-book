﻿<#
.SYNOPSIS
    设备安全功能禁用工具 - 精简版
.DESCRIPTION
    专为官方DG_Readiness工具包设计，不需要Disable.cmd
    版本: v1.0
#>

param([switch]$NoTitle = $false)

# ====== 初始化设置 ======
$scriptVersion = "1.0"
$logPath = "$env:USERPROFILE\DG_Disable_Log.txt"

# ====== 管理员权限检测 ======
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "`n错误：需要管理员权限！" -ForegroundColor Red
    Write-Host "请右键点击脚本 -> 以管理员身份运行" -ForegroundColor Cyan
    if (-not $NoTitle) { Read-Host "按 Enter 键退出" }
    exit 1
}

# ====== UI设置 ======
if (-not $NoTitle) {
    $Host.UI.RawUI.WindowTitle = "设备安全功能禁用工具 - v$scriptVersion"
    Write-Host "`n======================================================" -ForegroundColor Blue
    Write-Host " Microsoft Device Guard & Credential Guard 禁用工具" -ForegroundColor Cyan
    Write-Host " 基于 DG_Readiness_Tool_v3.6" -ForegroundColor Cyan
    Write-Host "======================================================" -ForegroundColor Blue
}

# ====== 日志系统 ======
try {
    "=== 设备安全功能禁用工具日志 ===`n" | Out-File $logPath
    "开始时间: $(Get-Date)`n" | Out-File $logPath -Append
    "操作系统: $([System.Environment]::OSVersion.VersionString)`n" | Out-File $logPath -Append
} catch {
    Write-Host "警告: 无法创建日志文件，继续操作..." -ForegroundColor Yellow
}

function Write-Log {
    param($Message)
    $logMessage = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'): $Message"
    try {
        $logMessage | Out-File $logPath -Append -ErrorAction Stop
    } catch {}
    Write-Host $logMessage
}

# ====== 验证DG工具存在 ======
$dgTool = "DG_Readiness_Tool_v3.6.ps1"
if (-not (Test-Path -Path $dgTool)) {
    Write-Log "错误：缺少必备文件 $dgTool"
    Write-Log "当前目录内容:"
    Get-ChildItem | Format-Table Name, Length | Out-String | Write-Host
    if (-not $NoTitle) { Read-Host "按 Enter 键退出" }
    exit 1
}

# ====== 禁用核心功能 ======
try {
    Write-Log "`n[阶段1] 禁用设备安全功能..."
    Write-Log "使用官方DG工具进行禁用操作..."
    
    # 直接调用官方工具
    Write-Log "执行命令: .\$dgTool -Disable"
    $output = & .\$dgTool -Disable *>&1 | Out-String
    
    Write-Log "`nDG工具输出:`n$output"
    Write-Log "`n禁用操作已完成" -ForegroundColor Green
    
}
catch {
    Write-Log "`n操作失败: $($_.Exception.Message)" -ForegroundColor Red
    Write-Log "错误详情: $($_.ScriptStackTrace)"
}

# ====== 重启提示 ======
if (-not $NoTitle) {
    Write-Host "`n======================================================" -ForegroundColor Blue
    Write-Host " 必须重启系统才能使更改生效" -ForegroundColor Yellow
    Write-Host "======================================================" -ForegroundColor Blue
    
    $choice = Read-Host "`n请选择:`n [1] 立即重启 (推荐)`n [2] 稍后手动重启`n选项(1/2)"
    
    if ($choice -eq "1") {
        Write-Log "`n系统将在10秒后重启..."
        10..1 | ForEach-Object {
            Write-Host "`r重启倒计时: $_ 秒" -NoNewline -ForegroundColor Yellow
            Start-Sleep -Seconds 1
        }
        Write-Log "`n正在重启系统..."
        Start-Process "shutdown.exe" -ArgumentList "/r", "/t", "0" -Wait
    }
}

# ====== 结束处理 ======
Write-Log "`n操作完成!"
Write-Log "日志文件: $logPath" -ForegroundColor Cyan
if (-not $NoTitle) {
    Read-Host "按 Enter 键关闭窗口"
}
